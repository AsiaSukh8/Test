
//alert('Name Surname');
// asdaksjdladlkasjdklasdlsaj
var Hello = 'hello !';
const bb = 1;
var boolVar = false;
if  (bb < 5){
    boolVar = true;
} 

if (boolVar) {
    document.write('true');
} else {
document.write('false');
}

var my_var = 15;
var myMyVar = 15;
var myMyVarStr = 'string_var';
var myArray = new Array();
myArray = [2, 3, 15];
var myArray1 = [];

var noVarVar;

noVarVar = 100;

var a = '12';
var b = '7.15';
a = +a;
b = +b;
var c = Math.round(a%b);

console.log('my variable1 = ', my_var, 'my variable2 = ', myMyVar);
console.log(`my myMyVarStr = ${myMyVarStr} my variable2 = ${myMyVar}`);

var todayDate = new Date();

function triangleS (sideA, sideB, date){
    var S = (sideA * sideB) / 2;
    console.log(`triangle S = ${S}, side a = ${sideA}, side b = ${sideB}`);
    console.log(date);
    // return S;
}

function calculteSMTH(){
    var varX = window.prompt('please input variable X below:');
    var clacResult = (varX**2 - 7*varX + 10)/(varX**2 - 8*varX + 12);
    window.alert(clacResult);
}